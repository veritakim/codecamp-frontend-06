export default function AAAPage() {
  // JS 구역
  

  return (
    //HTML 구역
    <div>
      안녕하세요ㅎ!!
      <input type="text" />
    </div>
    
  )
}
