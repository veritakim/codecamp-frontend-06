import styled from '@emotion/styled'

export const MyPage = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 101px 360px;
`

export const Wrapper = styled.div`
  width: 1200px;
  heigh: 100%;
  box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.2);
  padding: 60px 103px;
  
`



export const MyLogin = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-bottom: 80px;
`
export const MyTitle = styled.div`
  font-size: 36px;
  font-weight: 700;
  text-align: center;
  padding-bottom: 80px;
`

export const MyHeadWrapper = styled.div`
  display: flex; 
  flex-direction: row;
  padding-bottom: 40px;
`
export const MyLittleWrapper = styled.div`
  height: 92px;
  width: 100%;
  padding-right: 20px;
 
`

export const MySmallTitle = styled.div`
  font-size: 16px;
  padding-bottom: 16px;

`

export const MySmallInput = styled.input`
  width: 486px;
  height: 52px;
  border: 1px solid #BDBDBD;
  padding-left: 16px;
`

export const MyMiddleWrapper = styled.div`
  padding-bottom: 40px;
`

export const MyMiddleTextArea = styled.div`
  padding-bottom: 16px;
`

export const MyMiddleInput = styled.input`
  width: 100%;
  height: 52px;
  border: 1px solid #BDBDBD;
  padding-left: 16px;
`

export const MyMiddleText = styled.input`
  width: 100%;
  height: 480px;
  border: 1px solid #BDBDBD;
  padding-left: 16px;
`

export const MyAddrWrapper = styled.div`
padding-bottom: 30px;
`


export const MyAddrCode = styled.div`
  display: flex;
  flex-direction: row;
  padding-bottom: 16px;
`

export const MyAddrCodeInput = styled.input`
  width: 77px;
  height: 52px;
  border: 1px solid #BDBDBD;
  margin-right: 16px;
  text-align: center;
`
export const MyAddrBtn = styled.button`
  width: 124px;
  height: 52px;
  background-color: black;
  color: white;
  border: none;
`
export const MyAddrInput = styled.input`
  width: 100%;
  border: 1px solid #BDBDBD;
  padding-bottom: 30px;
  padding-left: 16px;
`

export const MyAddrWrappert = styled.div`
  width: 100%;
  padding-bottom: 37px; 
`

export const MyPhotoBody = styled.div`
  padding-bottom: 40px;
`

export const MyPhotoWrapper = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  padding: 0px 728px 0px 0px;
`
export const MyPhotoBtn = styled.div`
  width: 78px;
  height: 78px;
  background-color: #BDBDBD;
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  cursor: pointer;
`

export const MyPhotoSpanPlus = styled.span`
  font-size: 14px;
  color: #4F4F4F;
`
export const MyPhotoSpanUp = styled.span`
  font-size: 12px;
  color: #4F4F4F;
`

export const MyMain = styled.div`
  display: flex;
  flex-direction: row;
  padding-bottom: 80px;
`

export const MyMainDiv = styled.div`
  padding-right: 20px;
`

export const MyMainRadio = styled.input`
  margin-right: 10px;
  accent-color: darkgoldenrod;
  
`
export const MyRegisterBtnDiv = styled.div`
  width: 100%;
  text-align: center;
`
export const ExtenFont = styled(MyPhotoSpanPlus) ``

export const MyRegisterBtn = styled.button`
  height: 52px;
  width: 179px;
  background-color: #FFD600;
  border: none;
  font-size: 16px;
  cursor: pointer;
`

export const ErrorDiv = styled.div`
  color: red;
`

/* detailBoard */
export const Container = styled.div`
  width: 1200px;
  height: 100%;
  flex-direction: colomn;
  border: 1px solid black;
  padding: 80px 102px;
  box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.2);
`

export const DetailHead = styled.div`
  width: 996px; 
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  border-bottom: 1px solid #BDBDBD;
  padding-bottom: 20px;
}
`
export const UserInfo = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  
`

export const UserCircle = styled.div`
  font-size: 46.67px;
  padding-right: 16.67px;
`

export const UserNameBox = styled.div`
`

export const UserName = styled.div`
  font-size: 24px;
`
export const UserDate = styled.div`
  font-size: 16px;
  color: #828282;
`

export const UserIcon = styled.div`
  display: flex;
  align-items: center;
`

export const UserIconStyle = styled.div`
  font-size: 26.67px;
  padding-left: 35.33px;
  color: #FFD600;
  `

export const DetailContents = styled.div`
  width: 100%;
  padding-top: 80px;
`

export const DetailTitle = styled.div`
  font-size: 36px;
  font-weight: 700;
  padding-bottom: 40px;
`

export const DetailPictureBox = styled.div`
  width: 100%;
  text-align: center;
  padding: 40px 0px 40px 0px;
`

export const DetailImg = styled.img``

export const DetailContent = styled.div`
  width: 100%;
  font-size: 16px;
  padding-bottom: 120px;
`

export const DetailVideo = styled.div`
  text-align: center;
  padding-bottom: 162px;
`

export const DetailReactionBox = styled.div`
  display: flex;
  justify-content: center;
`

export const ThumbsUp = styled.div`
  display: flex;
  flex-direction: column;
  padding: 0px 59px 4px 0px;
  color: #FFD600;
`

export const ThumsDown = styled(ThumbsUp)`
  color: #828282;
  padding-right: 0px;
`

export const LikeCount = styled.span`
`
export const DisLikeCount = styled.span``

export const Bookmark = styled.div`
color : blue;
`