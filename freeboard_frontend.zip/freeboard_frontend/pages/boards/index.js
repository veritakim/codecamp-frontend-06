// 게시글 목록 조회하기 화면 만들기 ㅎ
import BoardList from "../../src/components/units/board/list/BoardList.container"

export default function ListPage () {

  return (
    <BoardList></BoardList>
  )
}