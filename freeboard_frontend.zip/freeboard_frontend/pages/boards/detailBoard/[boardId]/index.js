import DetailBoard from '../../../../src/components/units/board/detail/DetailBoard.container';



export default function DetailBoardPage () {
  return (
    <DetailBoard></DetailBoard>
  )
  
}

// 마테리얼 ui

// docs 찾아보기 

// facebook 블로그 보기 !! 