// import Container from "../../src/components/units/quiz/week5-01-1/component.container";
import Container from "../../src/components/units/quiz/week5-01-2/component.container";

export default function IndexPage () {

  // return <Container />
  return <Container />
}