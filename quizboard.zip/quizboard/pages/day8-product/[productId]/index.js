import DetailProductPage from "../../../src/components/units/board/08-product-detail/ProductWrite.container"

export default function DetailProduct () {

  return (
    <DetailProductPage />
  )
}