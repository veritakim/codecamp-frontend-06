import CreateProductWrite from "../../../../src/components/units/board/08-product-write/productWrite.container";

export default function UpdateProduct () {

  return (
    <CreateProductWrite isEdit={true} />
  )
}