import CreateProductWrite from "../../../src/components/units/board/08-product-write/productWrite.container"

export default function CreateProduct () {

  return (
    <CreateProductWrite isEdit={false}/>
  )
}