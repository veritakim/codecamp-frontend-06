import DetailBoard from '../../../../src/components/units/board/detailBoard/DetailBoard.container'



export default function DynamicRoutedPage () {
  

  return (
   <DetailBoard></DetailBoard>
  )
}

