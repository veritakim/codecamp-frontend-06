import {useRouter} from 'next/router'
import BoardList from '../../../src/components/units/board/list/BoardList.container'

export default function DynamicRoutingPage () {

  return (
    <BoardList></BoardList>
  )
}

