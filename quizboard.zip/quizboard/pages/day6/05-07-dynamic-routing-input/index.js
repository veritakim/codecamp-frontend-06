// import axios from 'axios'

import WriteBoardPage from "../../../src/components/units/board/write/WriteBoard.container";



export default function GraphqlMutationPage () {
  
  
  return (
    <WriteBoardPage></WriteBoardPage>
  )
}

