import LoginPage from "../login";

export default function LoginQuiz () {

  return <LoginPage />
} 