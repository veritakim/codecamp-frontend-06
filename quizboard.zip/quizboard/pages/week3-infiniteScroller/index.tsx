import Infinitecontainer from "../../src/components/units/board/board-infinite-scroll/infinite.container";

export default function InfiniteScroller () {


  return (
    <Infinitecontainer />
  )
}