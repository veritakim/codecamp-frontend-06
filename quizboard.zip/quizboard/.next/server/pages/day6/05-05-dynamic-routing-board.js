"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/day6/05-05-dynamic-routing-board";
exports.ids = ["pages/day6/05-05-dynamic-routing-board"];
exports.modules = {

/***/ "./pages/day6/05-05-dynamic-routing-board/index.js":
/*!*********************************************************!*\
  !*** ./pages/day6/05-05-dynamic-routing-board/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ DynamicRoutingPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _src_components_units_board_list_BoardList_container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../src/components/units/board/list/BoardList.container */ \"./src/components/units/board/list/BoardList.container.js\");\n\n\n\nfunction DynamicRoutingPage() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_units_board_list_BoardList_container__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/day6/05-05-dynamic-routing-board/index.js\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9kYXk2LzA1LTA1LWR5bmFtaWMtcm91dGluZy1ib2FyZC9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQXFDO0FBQytDO0FBRXJFLFFBQVEsQ0FBQ0Usa0JBQWtCLEdBQUksQ0FBQztJQUU3QyxNQUFNLDZFQUNIRCw0RkFBUzs7Ozs7QUFFZCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy9kYXk2LzA1LTA1LWR5bmFtaWMtcm91dGluZy1ib2FyZC9pbmRleC5qcz8wYjRmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7dXNlUm91dGVyfSBmcm9tICduZXh0L3JvdXRlcidcbmltcG9ydCBCb2FyZExpc3QgZnJvbSAnLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvdW5pdHMvYm9hcmQvbGlzdC9Cb2FyZExpc3QuY29udGFpbmVyJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEeW5hbWljUm91dGluZ1BhZ2UgKCkge1xuXG4gIHJldHVybiAoXG4gICAgPEJvYXJkTGlzdD48L0JvYXJkTGlzdD5cbiAgKVxufVxuXG4iXSwibmFtZXMiOlsidXNlUm91dGVyIiwiQm9hcmRMaXN0IiwiRHluYW1pY1JvdXRpbmdQYWdlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/day6/05-05-dynamic-routing-board/index.js\n");

/***/ }),

/***/ "./src/components/units/board/list/BoardList.container.js":
/*!****************************************************************!*\
  !*** ./src/components/units/board/list/BoardList.container.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ BoardListContainer)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _BoardList_presenter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./BoardList.presenter */ \"./src/components/units/board/list/BoardList.presenter.js\");\n\n\n\nfunction BoardListContainer() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const onClickMove1 = ()=>{\n        // 다 새로운 파일을 만들면 ,, 그룹으로 묶고\n        // \n        router.push(\"/day6/05-06-dynamic-routed-board/83011\");\n    };\n    const onClickMove2 = ()=>{\n        router.push(\"/day6/05-06-dynamic-routed-board/83012\");\n    };\n    const onClickMove3 = ()=>{\n        router.push(\"/day6/05-06-dynamic-routed-board/83013\");\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_BoardList_presenter__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n        onClickMove1: onClickMove1,\n        onClickMove2: onClickMove2,\n        onClickMove: onClickMove3\n    }, void 0, false, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/list/BoardList.container.js\",\n        lineNumber: 20,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9ib2FyZC9saXN0L0JvYXJkTGlzdC5jb250YWluZXIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFxQztBQUNVO0FBRWhDLFFBQVEsQ0FBQ0Usa0JBQWtCLEdBQUksQ0FBQztJQUM3QyxLQUFLLENBQUNDLE1BQU0sR0FBR0gsc0RBQVM7SUFFeEIsS0FBSyxDQUFDSSxZQUFZLE9BQVMsQ0FBQztRQUMxQixFQUEyQjtRQUMzQixFQUFHO1FBQ0hELE1BQU0sQ0FBQ0UsSUFBSSxDQUFDLENBQXdDO0lBQ3RELENBQUM7SUFDRCxLQUFLLENBQUNDLFlBQVksT0FBUyxDQUFDO1FBQzFCSCxNQUFNLENBQUNFLElBQUksQ0FBQyxDQUF3QztJQUN0RCxDQUFDO0lBQ0QsS0FBSyxDQUFDRSxZQUFZLE9BQVMsQ0FBQztRQUMxQkosTUFBTSxDQUFDRSxJQUFJLENBQUMsQ0FBd0M7SUFDdEQsQ0FBQztJQUVELE1BQU0sNkVBQ0hKLDREQUFXO1FBQ1JHLFlBQVksRUFBRUEsWUFBWTtRQUMxQkUsWUFBWSxFQUFFQSxZQUFZO1FBQzFCRSxXQUFXLEVBQUVELFlBQVk7Ozs7OztBQUVqQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tcG9uZW50cy91bml0cy9ib2FyZC9saXN0L0JvYXJkTGlzdC5jb250YWluZXIuanM/ZTg2ZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZVJvdXRlcn0gZnJvbSAnbmV4dC9yb3V0ZXInXG5pbXBvcnQgQm9hcmRMaXN0VUkgZnJvbSAnLi9Cb2FyZExpc3QucHJlc2VudGVyJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCb2FyZExpc3RDb250YWluZXIgKCkge1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuICBcbiAgY29uc3Qgb25DbGlja01vdmUxID0gKCkgPT4ge1xuICAgIC8vIOuLpCDsg4jroZzsmrQg7YyM7J287J2EIOunjOuTpOuptCAsLCDqt7jro7nsnLzroZwg66y26rOgXG4gICAgLy8gXG4gICAgcm91dGVyLnB1c2goXCIvZGF5Ni8wNS0wNi1keW5hbWljLXJvdXRlZC1ib2FyZC84MzAxMVwiKVxuICB9XG4gIGNvbnN0IG9uQ2xpY2tNb3ZlMiA9ICgpID0+IHtcbiAgICByb3V0ZXIucHVzaChcIi9kYXk2LzA1LTA2LWR5bmFtaWMtcm91dGVkLWJvYXJkLzgzMDEyXCIpXG4gIH1cbiAgY29uc3Qgb25DbGlja01vdmUzID0gKCkgPT4ge1xuICAgIHJvdXRlci5wdXNoKFwiL2RheTYvMDUtMDYtZHluYW1pYy1yb3V0ZWQtYm9hcmQvODMwMTNcIilcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPEJvYXJkTGlzdFVJXG4gICAgICAgIG9uQ2xpY2tNb3ZlMT17b25DbGlja01vdmUxfVxuICAgICAgICBvbkNsaWNrTW92ZTI9e29uQ2xpY2tNb3ZlMn1cbiAgICAgICAgb25DbGlja01vdmU9e29uQ2xpY2tNb3ZlM30+PC9Cb2FyZExpc3RVST5cbiAgKVxufVxuIl0sIm5hbWVzIjpbInVzZVJvdXRlciIsIkJvYXJkTGlzdFVJIiwiQm9hcmRMaXN0Q29udGFpbmVyIiwicm91dGVyIiwib25DbGlja01vdmUxIiwicHVzaCIsIm9uQ2xpY2tNb3ZlMiIsIm9uQ2xpY2tNb3ZlMyIsIm9uQ2xpY2tNb3ZlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/units/board/list/BoardList.container.js\n");

/***/ }),

/***/ "./src/components/units/board/list/BoardList.presenter.js":
/*!****************************************************************!*\
  !*** ./src/components/units/board/list/BoardList.presenter.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ BoardListlUI)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction BoardListlUI(props) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: props.onClickMove1,\n                children: \"83011번 게시글로 이동하기\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/list/BoardList.presenter.js\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: props.onClickMove2,\n                children: \"83012번 게시글로 이동하기\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/list/BoardList.presenter.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: props.onClickMove3,\n                children: \"83013번 게시글로 이동하기\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/list/BoardList.presenter.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/list/BoardList.presenter.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9ib2FyZC9saXN0L0JvYXJkTGlzdC5wcmVzZW50ZXIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNlLFFBQVEsQ0FBQ0EsWUFBWSxDQUFFQyxLQUFLLEVBQUUsQ0FBQztJQUU1QyxNQUFNLDZFQUNIQyxDQUFHOzt3RkFDREMsQ0FBTTtnQkFBQ0MsT0FBTyxFQUFFSCxLQUFLLENBQUNJLFlBQVk7MEJBQUUsQ0FBZ0I7Ozs7Ozt3RkFDbENGLENBQVo7Z0JBQUNDLE9BQU8sRUFBRUgsS0FBSyxDQUFDSyxZQUFZOzBCQUFFLENBQWdCOzs7Ozs7d0ZBQ2xDSCxDQUFaO2dCQUFDQyxPQUFPLEVBQUVILEtBQUssQ0FBQ00sWUFBWTswQkFBRSxDQUFnQjs7Ozs7Ozs7Ozs7O0FBSTNELENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21wb25lbnRzL3VuaXRzL2JvYXJkL2xpc3QvQm9hcmRMaXN0LnByZXNlbnRlci5qcz9hY2EyIl0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQm9hcmRMaXN0bFVJIChwcm9wcykge1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxidXR0b24gb25DbGljaz17cHJvcHMub25DbGlja01vdmUxfT44MzAxMeuyiCDqsozsi5zquIDroZwg7J2064+Z7ZWY6riwPC9idXR0b24+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e3Byb3BzLm9uQ2xpY2tNb3ZlMn0+ODMwMTLrsogg6rKM7Iuc6riA66GcIOydtOuPme2VmOq4sDwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtwcm9wcy5vbkNsaWNrTW92ZTN9PjgzMDEz67KIIOqyjOyLnOq4gOuhnCDsnbTrj5ntlZjquLA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cblxuICApXG59Il0sIm5hbWVzIjpbIkJvYXJkTGlzdGxVSSIsInByb3BzIiwiZGl2IiwiYnV0dG9uIiwib25DbGljayIsIm9uQ2xpY2tNb3ZlMSIsIm9uQ2xpY2tNb3ZlMiIsIm9uQ2xpY2tNb3ZlMyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/units/board/list/BoardList.presenter.js\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/day6/05-05-dynamic-routing-board/index.js"));
module.exports = __webpack_exports__;

})();