"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/day6/05-06-dynamic-routed-board/[number]";
exports.ids = ["pages/day6/05-06-dynamic-routed-board/[number]"];
exports.modules = {

/***/ "./pages/day6/05-06-dynamic-routed-board/[number]/index.js":
/*!*****************************************************************!*\
  !*** ./pages/day6/05-06-dynamic-routed-board/[number]/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ DynamicRoutedPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _src_components_units_board_detailBoard_DetailBoard_container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../src/components/units/board/detailBoard/DetailBoard.container */ \"./src/components/units/board/detailBoard/DetailBoard.container.js\");\n\n\nfunction DynamicRoutedPage() {\n    return(// <div>안녕하세요</div>\n    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_units_board_detailBoard_DetailBoard_container__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/day6/05-06-dynamic-routed-board/[number]/index.js\",\n        lineNumber: 10,\n        columnNumber: 4\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9kYXk2LzA1LTA2LWR5bmFtaWMtcm91dGVkLWJvYXJkL1tudW1iZXJdL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQWtHO0FBSW5GLFFBQVEsQ0FBQ0MsaUJBQWlCLEdBQUksQ0FBQztJQUc1QyxNQUFNLENBQ0osRUFBbUI7Z0ZBQ25CRCxxR0FBVzs7Ozs7QUFFZixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy9kYXk2LzA1LTA2LWR5bmFtaWMtcm91dGVkLWJvYXJkL1tudW1iZXJdL2luZGV4LmpzP2YzYTQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IERldGFpbEJvYXJkIGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL3VuaXRzL2JvYXJkL2RldGFpbEJvYXJkL0RldGFpbEJvYXJkLmNvbnRhaW5lcidcblxuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIER5bmFtaWNSb3V0ZWRQYWdlICgpIHtcbiAgXG5cbiAgcmV0dXJuIChcbiAgICAvLyA8ZGl2PuyViOuFle2VmOyEuOyalDwvZGl2PlxuICAgPERldGFpbEJvYXJkPjwvRGV0YWlsQm9hcmQ+XG4gIClcbn1cblxuIl0sIm5hbWVzIjpbIkRldGFpbEJvYXJkIiwiRHluYW1pY1JvdXRlZFBhZ2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/day6/05-06-dynamic-routed-board/[number]/index.js\n");

/***/ }),

/***/ "./src/components/units/board/detailBoard/DetailBoard.container.js":
/*!*************************************************************************!*\
  !*** ./src/components/units/board/detailBoard/DetailBoard.container.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ DetailBoard)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _DetailBoard_queries__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./DetailBoard.queries */ \"./src/components/units/board/detailBoard/DetailBoard.queries.js\");\n/* harmony import */ var _DetailBoard_presenter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./DetailBoard.presenter */ \"./src/components/units/board/detailBoard/DetailBoard.presenter.js\");\n\n\n\n\n\nfunction DetailBoard() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    console.log(router);\n    const { data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useQuery)(_DetailBoard_queries__WEBPACK_IMPORTED_MODULE_3__.FETCH_BOARD, {\n        variables: {\n            number: Number(router.query.number) // 83013\n        }\n    });\n    console.log(data);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_DetailBoard_presenter__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n        data: data\n    }, void 0, false, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/detailBoard/DetailBoard.container.js\",\n        lineNumber: 19,\n        columnNumber: 4\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9ib2FyZC9kZXRhaWxCb2FyZC9EZXRhaWxCb2FyZC5jb250YWluZXIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUF1QztBQUNBO0FBQ1U7QUFDRTtBQUVwQyxRQUFRLENBQUNJLFdBQVcsR0FBRyxDQUFDO0lBQ3ZDLEtBQUssQ0FBQ0MsTUFBTSxHQUFHSixzREFBUztJQUN0QkssT0FBTyxDQUFDQyxHQUFHLENBQUNGLE1BQU07SUFFbEIsS0FBSyxDQUFDLENBQUNHLENBQUFBLElBQUksR0FBQyxHQUFHUix3REFBUSxDQUFDRSw2REFBVyxFQUFFLENBQUM7UUFDcENPLFNBQVMsRUFBRSxDQUFDO1lBQ1ZDLE1BQU0sRUFBRUMsTUFBTSxDQUFDTixNQUFNLENBQUNPLEtBQUssQ0FBQ0YsTUFBTSxDQUFFLENBQVE7UUFDOUMsQ0FBQztJQUNILENBQUM7SUFDQ0osT0FBTyxDQUFDQyxHQUFHLENBQUNDLElBQUk7SUFHbEIsTUFBTSw2RUFDSkwsOERBQWE7UUFBQ0ssSUFBSSxFQUFHQSxJQUFJOzs7Ozs7QUFHN0IsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vc3JjL2NvbXBvbmVudHMvdW5pdHMvYm9hcmQvZGV0YWlsQm9hcmQvRGV0YWlsQm9hcmQuY29udGFpbmVyLmpzP2E4ZTAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHt1c2VRdWVyeX0gZnJvbSAnQGFwb2xsby9jbGllbnQnXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcidcbmltcG9ydCB7RkVUQ0hfQk9BUkR9IGZyb20gJy4vRGV0YWlsQm9hcmQucXVlcmllcydcbmltcG9ydCBCb2FyZERldGFpbFVpIGZyb20gJy4vRGV0YWlsQm9hcmQucHJlc2VudGVyJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEZXRhaWxCb2FyZCAoKXtcbmNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnNvbGUubG9nKHJvdXRlcikgXG4gICAgICAgICAgICAgICAgICAgIFxuICBjb25zdCB7ZGF0YX0gPSB1c2VRdWVyeShGRVRDSF9CT0FSRCwge1xuICAgIHZhcmlhYmxlczoge1xuICAgICAgbnVtYmVyOiBOdW1iZXIocm91dGVyLnF1ZXJ5Lm51bWJlcikgLy8gODMwMTNcbiAgICB9XG4gIH0pXG4gICAgY29uc29sZS5sb2coZGF0YSlcblxuXG4gIHJldHVybiAoXG4gICA8Qm9hcmREZXRhaWxVaSBkYXRhID17ZGF0YX0vPlxuICAgIFxuICApXG59Il0sIm5hbWVzIjpbInVzZVF1ZXJ5IiwidXNlUm91dGVyIiwiRkVUQ0hfQk9BUkQiLCJCb2FyZERldGFpbFVpIiwiRGV0YWlsQm9hcmQiLCJyb3V0ZXIiLCJjb25zb2xlIiwibG9nIiwiZGF0YSIsInZhcmlhYmxlcyIsIm51bWJlciIsIk51bWJlciIsInF1ZXJ5Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/units/board/detailBoard/DetailBoard.container.js\n");

/***/ }),

/***/ "./src/components/units/board/detailBoard/DetailBoard.presenter.js":
/*!*************************************************************************!*\
  !*** ./src/components/units/board/detailBoard/DetailBoard.presenter.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ BoardDetailUi)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction BoardDetailUi(props) {\n    var ref, ref1, ref2, ref3;\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    (ref = props.data) === null || ref === void 0 ? void 0 : ref.fetchBoard.number,\n                    \"번 게시글에 오신것을 환영합니다\"\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/detailBoard/DetailBoard.presenter.js\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"작성자: \",\n                    (ref1 = props.data) === null || ref1 === void 0 ? void 0 : ref1.fetchBoard.writer\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/detailBoard/DetailBoard.presenter.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"제목: \",\n                    (ref2 = props.data) === null || ref2 === void 0 ? void 0 : ref2.fetchBoard.title\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/detailBoard/DetailBoard.presenter.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"내용: \",\n                    (ref3 = props.data) === null || ref3 === void 0 ? void 0 : ref3.fetchBoard.contents\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/detailBoard/DetailBoard.presenter.js\",\n                lineNumber: 9,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/src/components/units/board/detailBoard/DetailBoard.presenter.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9ib2FyZC9kZXRhaWxCb2FyZC9EZXRhaWxCb2FyZC5wcmVzZW50ZXIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNlLFFBQVEsQ0FBQ0EsYUFBYSxDQUFFQyxLQUFLLEVBQUUsQ0FBQztRQUluQ0EsR0FBVSxFQUNMQSxJQUFnQixFQUNYQSxJQUFRLEVBQ1ZBLElBQU07SUFMeEIsTUFBTSw2RUFDSEMsQ0FBRzs7d0ZBQ0RBLENBQUc7O3FCQUFFRCxHQUFVLEdBQVZBLEtBQUssQ0FBQ0UsSUFBSSxjQUFWRixHQUFVLEtBQVZBLElBQUksQ0FBSkEsQ0FBc0IsR0FBdEJBLElBQUksQ0FBSkEsQ0FBc0IsR0FBdEJBLEdBQVUsQ0FBRUcsVUFBVSxDQUFDQyxNQUFNO29CQUFDLENBQTZDOzs7Ozs7O3dGQUNoRkgsQ0FBRzs7b0JBQUMsQ0FBVztxQkFBQ0QsSUFBVSxHQUFWQSxLQUFLLENBQUNFLElBQUksY0FBVkYsSUFBVSxLQUFWQSxJQUFJLENBQUpBLENBQXNCLEdBQXRCQSxJQUFJLENBQUpBLENBQXNCLEdBQXRCQSxJQUFVLENBQUVHLFVBQVUsQ0FBQ0UsTUFBTTs7Ozs7Ozt3RkFDN0NKLENBQUc7O29CQUFDLENBQVE7cUJBQUNELElBQVUsR0FBVkEsS0FBSyxDQUFDRSxJQUFJLGNBQVZGLElBQVUsS0FBVkEsSUFBSSxDQUFKQSxDQUFzQixHQUF0QkEsSUFBSSxDQUFKQSxDQUFzQixHQUF0QkEsSUFBVSxDQUFFRyxVQUFVLENBQUNHLEtBQUs7Ozs7Ozs7d0ZBQ3pDTCxDQUFHOztvQkFBQyxDQUFJO3FCQUFDRCxJQUFVLEdBQVZBLEtBQUssQ0FBQ0UsSUFBSSxjQUFWRixJQUFVLEtBQVZBLElBQUksQ0FBSkEsQ0FBc0IsR0FBdEJBLElBQUksQ0FBSkEsQ0FBc0IsR0FBdEJBLElBQVUsQ0FBRUcsVUFBVSxDQUFDSSxRQUFROzs7Ozs7Ozs7Ozs7O0FBRy9DLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21wb25lbnRzL3VuaXRzL2JvYXJkL2RldGFpbEJvYXJkL0RldGFpbEJvYXJkLnByZXNlbnRlci5qcz8xNDI4Il0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQm9hcmREZXRhaWxVaSAocHJvcHMpIHtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2Pntwcm9wcy5kYXRhPy5mZXRjaEJvYXJkLm51bWJlcn3rsogg6rKM7Iuc6riA7JeQIOyYpOyLoOqyg+ydhCDtmZjsmIHtlanri4jri6Q8L2Rpdj5cbiAgICAgIDxkaXY+7J6R7ISx7J6QOiB7cHJvcHMuZGF0YT8uZmV0Y2hCb2FyZC53cml0ZXJ9PC9kaXY+XG4gICAgICA8ZGl2PuygnOuqqToge3Byb3BzLmRhdGE/LmZldGNoQm9hcmQudGl0bGV9PC9kaXY+XG4gICAgICA8ZGl2PuuCtOyaqToge3Byb3BzLmRhdGE/LmZldGNoQm9hcmQuY29udGVudHN9PC9kaXY+XG4gIDwvZGl2PlxuICApXG59Il0sIm5hbWVzIjpbIkJvYXJkRGV0YWlsVWkiLCJwcm9wcyIsImRpdiIsImRhdGEiLCJmZXRjaEJvYXJkIiwibnVtYmVyIiwid3JpdGVyIiwidGl0bGUiLCJjb250ZW50cyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/units/board/detailBoard/DetailBoard.presenter.js\n");

/***/ }),

/***/ "./src/components/units/board/detailBoard/DetailBoard.queries.js":
/*!***********************************************************************!*\
  !*** ./src/components/units/board/detailBoard/DetailBoard.queries.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"FETCH_BOARD\": () => (/* binding */ FETCH_BOARD)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n\nconst FETCH_BOARD = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n  query fetchBoard($number: Int){\n  fetchBoard(number: $number){\n    writer\n    title\n    contents\n    like\n    number\n  }\n}\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9ib2FyZC9kZXRhaWxCb2FyZC9EZXRhaWxCb2FyZC5xdWVyaWVzLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFrQztBQUUzQixLQUFLLENBQUNDLFdBQVcsR0FBR0QsK0NBQUcsQ0FBRTs7Ozs7Ozs7OztBQVVoQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vc3JjL2NvbXBvbmVudHMvdW5pdHMvYm9hcmQvZGV0YWlsQm9hcmQvRGV0YWlsQm9hcmQucXVlcmllcy5qcz8yZjVmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Z3FsfSBmcm9tICdAYXBvbGxvL2NsaWVudCdcblxuZXhwb3J0IGNvbnN0IEZFVENIX0JPQVJEID0gZ3FsIGBcbiAgcXVlcnkgZmV0Y2hCb2FyZCgkbnVtYmVyOiBJbnQpe1xuICBmZXRjaEJvYXJkKG51bWJlcjogJG51bWJlcil7XG4gICAgd3JpdGVyXG4gICAgdGl0bGVcbiAgICBjb250ZW50c1xuICAgIGxpa2VcbiAgICBudW1iZXJcbiAgfVxufVxuYFxuIl0sIm5hbWVzIjpbImdxbCIsIkZFVENIX0JPQVJEIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/units/board/detailBoard/DetailBoard.queries.js\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/day6/05-06-dynamic-routed-board/[number]/index.js"));
module.exports = __webpack_exports__;

})();