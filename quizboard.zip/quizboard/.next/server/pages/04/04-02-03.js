"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/04/04-02-03";
exports.ids = ["pages/04/04-02-03"];
exports.modules = {

/***/ "./pages/04/04-02-03/index.js":
/*!************************************!*\
  !*** ./pages/04/04-02-03/index.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ CreateMutationPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst CREATE_BOARD = _apollo_client__WEBPACK_IMPORTED_MODULE_2__.gql`\n  mutation createSelfBoard($writer: String, $title: String, $contents: String){\n    createBoard(writer: $writer, title: $title, contents: $contents) {\n      _id\n      number\n      message\n    }\n  } \n`;\nfunction CreateMutationPage() {\n    const { 0: writer , 1: setWriter  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const { 0: title , 1: setTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const { 0: contents , 1: setContents  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [callApi] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_2__.useMutation)(CREATE_BOARD);\n    const callInput = async ()=>{\n        const result = await callApi({\n            variables: {\n                writer: writer,\n                title: title,\n                contents: contents\n            }\n        });\n        console.log(result.data.createBoard.number);\n        console.log(result.data.createBoard.message);\n    };\n    const onChangeWriter = (event)=>{\n        setWriter(event.target.value);\n    };\n    const onChangeTitle = (event)=>{\n        setTitle(event.target.value);\n    };\n    const onChangeContents = (event)=>{\n        setContents(event.target.value);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            \"작성자 :\",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"text\",\n                onChange: onChangeWriter\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/04/04-02-03/index.js\",\n                lineNumber: 46,\n                columnNumber: 9\n            }, this),\n            \"제목 :\",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"text\",\n                onChange: onChangeTitle\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/04/04-02-03/index.js\",\n                lineNumber: 48,\n                columnNumber: 9\n            }, this),\n            \"내용 :\",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"text\",\n                onChange: onChangeContents\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/04/04-02-03/index.js\",\n                lineNumber: 50,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: callInput,\n                children: \"요청하기\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/04/04-02-03/index.js\",\n                lineNumber: 51,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/04/04-02-03/index.js\",\n        lineNumber: 44,\n        columnNumber: 7\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wNC8wNC0wMi0wMy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUE4QjtBQUNpQjtBQUUvQyxLQUFLLENBQUNHLFlBQVksR0FBR0QsK0NBQUcsQ0FBQzs7Ozs7Ozs7QUFRekI7QUFFZSxRQUFRLENBQUNFLGtCQUFrQixHQUFJLENBQUM7SUFDN0MsS0FBSyxNQUFFQyxNQUFNLE1BQUVDLFNBQVMsTUFBSU4sK0NBQVEsQ0FBQyxDQUFFO0lBQ3ZDLEtBQUssTUFBRU8sS0FBSyxNQUFFQyxRQUFRLE1BQUlSLCtDQUFRLENBQUMsQ0FBRTtJQUNyQyxLQUFLLE1BQUVTLFFBQVEsTUFBRUMsV0FBVyxNQUFJViwrQ0FBUSxDQUFDLENBQUU7SUFFM0MsS0FBSyxFQUFFVyxPQUFPLElBQUlWLDJEQUFXLENBQUNFLFlBQVk7SUFFMUMsS0FBSyxDQUFDUyxTQUFTLGFBQWUsQ0FBQztRQUM3QixLQUFLLENBQUNDLE1BQU0sR0FBRyxLQUFLLENBQUNGLE9BQU8sQ0FBQyxDQUFDO1lBQzVCRyxTQUFTLEVBQUUsQ0FBQ1Q7Z0JBQUFBLE1BQU0sRUFBRUEsTUFBTTtnQkFBRUUsS0FBSyxFQUFFQSxLQUFLO2dCQUFFRSxRQUFRLEVBQUVBLFFBQVE7WUFBQSxDQUFDO1FBQy9ELENBQUM7UUFHRE0sT0FBTyxDQUFDQyxHQUFHLENBQUNILE1BQU0sQ0FBQ0ksSUFBSSxDQUFDQyxXQUFXLENBQUNDLE1BQU07UUFDMUNKLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSCxNQUFNLENBQUNJLElBQUksQ0FBQ0MsV0FBVyxDQUFDRSxPQUFPO0lBQzdDLENBQUM7SUFFQyxLQUFLLENBQUNDLGNBQWMsSUFBSUMsS0FBSyxHQUFLLENBQUM7UUFDakNoQixTQUFTLENBQUNnQixLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztJQUM5QixDQUFDO0lBQ0QsS0FBSyxDQUFDQyxhQUFhLElBQUlILEtBQUssR0FBSyxDQUFDO1FBQ2hDZCxRQUFRLENBQUNjLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLO0lBQzdCLENBQUM7SUFDRCxLQUFLLENBQUNFLGdCQUFnQixJQUFJSixLQUFLLEdBQUssQ0FBQztRQUNuQ1osV0FBVyxDQUFDWSxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztJQUNoQyxDQUFDO0lBSUQsTUFBTSw2RUFDSEcsQ0FBRzs7WUFBQyxDQUVIO3dGQUFDQyxDQUFLO2dCQUFDQyxJQUFJLEVBQUMsQ0FBTTtnQkFBQ0MsUUFBUSxFQUFFVCxjQUFjOzs7Ozs7WUFBSSxDQUUvQzt3RkFBQ08sQ0FBSztnQkFBQ0MsSUFBSSxFQUFDLENBQU07Z0JBQUNDLFFBQVEsRUFBRUwsYUFBYTs7Ozs7O1lBQUksQ0FFOUM7d0ZBQUNHLENBQUs7Z0JBQUNDLElBQUksRUFBQyxDQUFNO2dCQUFDQyxRQUFRLEVBQUVKLGdCQUFnQjs7Ozs7O3dGQUM1Q0ssQ0FBTTtnQkFBQ0MsT0FBTyxFQUFFcEIsU0FBUzswQkFBRSxDQUFJOzs7Ozs7Ozs7Ozs7QUFNeEMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDQvMDQtMDItMDMvaW5kZXguanM/ZjA0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge3VzZVN0YXRlfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7dXNlTXV0YXRpb24sIGdxbH0gZnJvbSAnQGFwb2xsby9jbGllbnQnXG5cbmNvbnN0IENSRUFURV9CT0FSRCA9IGdxbGBcbiAgbXV0YXRpb24gY3JlYXRlU2VsZkJvYXJkKCR3cml0ZXI6IFN0cmluZywgJHRpdGxlOiBTdHJpbmcsICRjb250ZW50czogU3RyaW5nKXtcbiAgICBjcmVhdGVCb2FyZCh3cml0ZXI6ICR3cml0ZXIsIHRpdGxlOiAkdGl0bGUsIGNvbnRlbnRzOiAkY29udGVudHMpIHtcbiAgICAgIF9pZFxuICAgICAgbnVtYmVyXG4gICAgICBtZXNzYWdlXG4gICAgfVxuICB9IFxuYFxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDcmVhdGVNdXRhdGlvblBhZ2UgKCkge1xuICBjb25zdCBbd3JpdGVyLCBzZXRXcml0ZXJdID0gdXNlU3RhdGUoXCJcIilcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShcIlwiKVxuICBjb25zdCBbY29udGVudHMsIHNldENvbnRlbnRzXSA9IHVzZVN0YXRlKFwiXCIpXG5cbiAgY29uc3QgW2NhbGxBcGldID0gdXNlTXV0YXRpb24oQ1JFQVRFX0JPQVJEKVxuXG4gIGNvbnN0IGNhbGxJbnB1dCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjYWxsQXBpKHtcbiAgICAgIHZhcmlhYmxlczoge3dyaXRlcjogd3JpdGVyLCB0aXRsZTogdGl0bGUsIGNvbnRlbnRzOiBjb250ZW50c31cbiAgICB9KVxuICAgIFxuICAgIFxuICAgIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhLmNyZWF0ZUJvYXJkLm51bWJlcilcbiAgICBjb25zb2xlLmxvZyhyZXN1bHQuZGF0YS5jcmVhdGVCb2FyZC5tZXNzYWdlKVxuICB9XG5cbiAgICBjb25zdCBvbkNoYW5nZVdyaXRlciA9IChldmVudCkgPT4ge1xuICAgICAgc2V0V3JpdGVyKGV2ZW50LnRhcmdldC52YWx1ZSlcbiAgICB9XG4gICAgY29uc3Qgb25DaGFuZ2VUaXRsZSA9IChldmVudCkgPT4ge1xuICAgICAgc2V0VGl0bGUoZXZlbnQudGFyZ2V0LnZhbHVlKVxuICAgIH1cbiAgICBjb25zdCBvbkNoYW5nZUNvbnRlbnRzID0gKGV2ZW50KSA9PiB7XG4gICAgICBzZXRDb250ZW50cyhldmVudC50YXJnZXQudmFsdWUpXG4gICAgfVxuXG5cbiAgICBcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cbiAgICAgICAg7J6R7ISx7J6QIDogXG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG9uQ2hhbmdlPXtvbkNoYW5nZVdyaXRlcn0gLz5cbiAgICAgICAg7KCc66qpIDpcbiAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgb25DaGFuZ2U9e29uQ2hhbmdlVGl0bGV9IC8+XG4gICAgICAgIOuCtOyaqSA6XG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIG9uQ2hhbmdlPXtvbkNoYW5nZUNvbnRlbnRzfSAvPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2NhbGxJbnB1dH0+7JqU7LKt7ZWY6riwPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIFxuICBcbiAgXG59Il0sIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTXV0YXRpb24iLCJncWwiLCJDUkVBVEVfQk9BUkQiLCJDcmVhdGVNdXRhdGlvblBhZ2UiLCJ3cml0ZXIiLCJzZXRXcml0ZXIiLCJ0aXRsZSIsInNldFRpdGxlIiwiY29udGVudHMiLCJzZXRDb250ZW50cyIsImNhbGxBcGkiLCJjYWxsSW5wdXQiLCJyZXN1bHQiLCJ2YXJpYWJsZXMiLCJjb25zb2xlIiwibG9nIiwiZGF0YSIsImNyZWF0ZUJvYXJkIiwibnVtYmVyIiwibWVzc2FnZSIsIm9uQ2hhbmdlV3JpdGVyIiwiZXZlbnQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm9uQ2hhbmdlVGl0bGUiLCJvbkNoYW5nZUNvbnRlbnRzIiwiZGl2IiwiaW5wdXQiLCJ0eXBlIiwib25DaGFuZ2UiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/04/04-02-03/index.js\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/04/04-02-03/index.js"));
module.exports = __webpack_exports__;

})();