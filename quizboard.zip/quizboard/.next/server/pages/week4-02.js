"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/week4-02";
exports.ids = ["pages/week4-02"];
exports.modules = {

/***/ "./pages/week4-02/index.tsx":
/*!**********************************!*\
  !*** ./pages/week4-02/index.tsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ QuizCount)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction QuizCount() {\n    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        var ref;\n        (ref = inputRef.current) === null || ref === void 0 ? void 0 : ref.focus();\n    }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n            type: \"password\",\n            ref: inputRef\n        }, void 0, false, {\n            fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/week4-02/index.tsx\",\n            lineNumber: 14,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/week4-02/index.tsx\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy93ZWVrNC0wMi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQXlDO0FBRzFCLFFBQVEsQ0FBQ0UsU0FBUyxHQUFJLENBQUM7SUFDcEMsS0FBSyxDQUFDQyxRQUFRLEdBQUdGLDZDQUFNLENBQW1CLElBQUk7SUFFOUNELGdEQUFTLEtBQU8sQ0FBQztZQUNmRyxHQUFnQjtTQUFoQkEsR0FBZ0IsR0FBaEJBLFFBQVEsQ0FBQ0MsT0FBTyxjQUFoQkQsR0FBZ0IsS0FBaEJBLElBQUksQ0FBSkEsQ0FBdUIsR0FBdkJBLElBQUksQ0FBSkEsQ0FBdUIsR0FBdkJBLEdBQWdCLENBQUVFLEtBQUs7SUFDekIsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUdKLE1BQU0sNkVBQ0hDLENBQUc7OEZBQ0RDLENBQUs7WUFBQ0MsSUFBSSxFQUFDLENBQVU7WUFBQ0MsR0FBRyxFQUFFTixRQUFROzs7Ozs7Ozs7OztBQUsxQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy93ZWVrNC0wMi9pbmRleC50c3g/MzUxNiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiXG5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUXVpekNvdW50ICgpIHtcbiAgY29uc3QgaW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG4gIFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gIH0sW10pXG4gIFxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiByZWY9e2lucHV0UmVmfSAvPlxuICAgIDwvZGl2PlxuXG4gIClcblxufSJdLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJRdWl6Q291bnQiLCJpbnB1dFJlZiIsImN1cnJlbnQiLCJmb2N1cyIsImRpdiIsImlucHV0IiwidHlwZSIsInJlZiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/week4-02/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/week4-02/index.tsx"));
module.exports = __webpack_exports__;

})();