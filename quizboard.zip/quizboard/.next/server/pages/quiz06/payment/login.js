"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/quiz06/payment/login";
exports.ids = ["pages/quiz06/payment/login"];
exports.modules = {

/***/ "./pages/quiz06/payment/login/index.tsx":
/*!**********************************************!*\
  !*** ./pages/quiz06/payment/login/index.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ PaymentLoginPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../src/commons/store */ \"./src/commons/store/index.ts\");\n\n\n\n\n\n\nconst LOGIN_USER = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  mutation loginUser($email: String!, $password: String!) {\n    loginUser(email: $email, password: $password){\n      accessToken\n    }\n  }\n`;\nconst FETCH_USER_LOGGED_IN = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  query fetchUserLoggedIn {\n    fetchUserLoggedIn {\n      _id\n      email\n      name\n      userPoint{\n        amount\n      }\n    }\n  }\n`;\nfunction PaymentLoginPage() {\n    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const { 0: password , 1: setPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const [loginUser] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useMutation)(LOGIN_USER);\n    const [, setUserInfo] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_5__.userInfomationState);\n    const [, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_5__.accessTokenState);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const client = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useApolloClient)();\n    const onChangeEmail = (e)=>{\n        setEmail(e.target.value);\n    };\n    const onChangePassword = (e)=>{\n        setPassword(e.target.value);\n    };\n    const onSubmitLogin = async (data)=>{\n        const result = await loginUser({\n            variables: {\n                email,\n                password\n            }\n        });\n        const accessToken = result.data.loginUser.accessToken;\n        setAccessToken(accessToken);\n        const resultUserInfo = await client.query({\n            query: FETCH_USER_LOGGED_IN,\n            context: {\n                headers: {\n                    Authorization: `Bearer ${accessToken}`\n                }\n            }\n        });\n        const userInfo = resultUserInfo.data.fetchUserLoggedIn;\n        setUserInfo(userInfo);\n        setAccessToken(accessToken);\n        localStorage.setItem(\"accessToken\", accessToken);\n        localStorage.setItem(\"userInfo\", JSON.stringify(userInfo));\n        router.push('/quiz06/payment/loading');\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"로그인 : \",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                        type: \"text\",\n                        onChange: onChangeEmail\n                    }, void 0, false, {\n                        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/quiz06/payment/login/index.tsx\",\n                        lineNumber: 86,\n                        columnNumber: 20\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/quiz06/payment/login/index.tsx\",\n                lineNumber: 86,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"비밀번호 : \",\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                        type: \"password\",\n                        onChange: onChangePassword\n                    }, void 0, false, {\n                        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/quiz06/payment/login/index.tsx\",\n                        lineNumber: 87,\n                        columnNumber: 21\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/quiz06/payment/login/index.tsx\",\n                lineNumber: 87,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    onClick: onSubmitLogin,\n                    children: \"로그인\"\n                }, void 0, false, {\n                    fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/quiz06/payment/login/index.tsx\",\n                    lineNumber: 88,\n                    columnNumber: 14\n                }, this)\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/quiz06/payment/login/index.tsx\",\n                lineNumber: 88,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/quiz06/payment/login/index.tsx\",\n        lineNumber: 85,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9xdWl6MDYvcGF5bWVudC9sb2dpbi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFrRTtBQUMzQjtBQUNQO0FBRU87QUFDOEM7QUFFckYsS0FBSyxDQUFDUSxVQUFVLEdBQUdSLCtDQUFHLENBQUM7Ozs7OztBQU12QjtBQUlBLEtBQUssQ0FBQ1Msb0JBQW9CLEdBQUdULCtDQUFHLENBQUM7Ozs7Ozs7Ozs7O0FBV2pDO0FBSWUsUUFBUSxDQUFDVSxnQkFBZ0IsR0FBSSxDQUFDO0lBQzNDLEtBQUssTUFBRUMsS0FBSyxNQUFFQyxRQUFRLE1BQUlSLCtDQUFRLENBQUMsQ0FBRTtJQUNyQyxLQUFLLE1BQUVTLFFBQVEsTUFBRUMsV0FBVyxNQUFJViwrQ0FBUSxDQUFDLENBQUU7SUFDM0MsS0FBSyxFQUFFVyxTQUFTLElBQUliLDJEQUFXLENBQUNNLFVBQVU7SUFDMUMsS0FBSyxJQUFJUSxXQUFXLElBQUtYLHNEQUFjLENBQUNFLG1FQUFtQjtJQUMzRCxLQUFLLElBQUlVLGNBQWMsSUFBSVosc0RBQWMsQ0FBQ0MsZ0VBQWdCO0lBRTFELEtBQUssQ0FBQ1ksTUFBTSxHQUFHZixzREFBUztJQUV4QixLQUFLLENBQUNnQixNQUFNLEdBQUdsQiwrREFBZTtJQUU5QixLQUFLLENBQUNtQixhQUFhLElBQUlDLENBQUMsR0FBSyxDQUFDO1FBQzVCVCxRQUFRLENBQUNTLENBQUMsQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLO0lBQ3pCLENBQUM7SUFFRCxLQUFLLENBQUNDLGdCQUFnQixJQUFJSCxDQUFDLEdBQUssQ0FBQztRQUMvQlAsV0FBVyxDQUFDTyxDQUFDLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztJQUM1QixDQUFDO0lBRUQsS0FBSyxDQUFDRSxhQUFhLFVBQVVDLElBQUksR0FBSyxDQUFDO1FBQ3JDLEtBQUssQ0FBQ0MsTUFBTSxHQUFHLEtBQUssQ0FBQ1osU0FBUyxDQUFDLENBQUM7WUFDOUJhLFNBQVMsRUFBRSxDQUFDO2dCQUNWakIsS0FBSztnQkFDTEUsUUFBUTtZQUNWLENBQUM7UUFDSCxDQUFDO1FBRUQsS0FBSyxDQUFDZ0IsV0FBVyxHQUFHRixNQUFNLENBQUNELElBQUksQ0FBQ1gsU0FBUyxDQUFDYyxXQUFXO1FBQ3JEWixjQUFjLENBQUNZLFdBQVc7UUFFMUIsS0FBSyxDQUFDQyxjQUFjLEdBQUcsS0FBSyxDQUFDWCxNQUFNLENBQUNZLEtBQUssQ0FBQyxDQUFDO1lBQ3pDQSxLQUFLLEVBQUV0QixvQkFBb0I7WUFDM0J1QixPQUFPLEVBQUUsQ0FBQztnQkFDUkMsT0FBTyxFQUFFLENBQUM7b0JBQ1JDLGFBQWEsR0FBRyxPQUFPLEVBQUVMLFdBQVc7Z0JBQ3RDLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztRQUVELEtBQUssQ0FBQ00sUUFBUSxHQUFHTCxjQUFjLENBQUNKLElBQUksQ0FBQ1UsaUJBQWlCO1FBRXREcEIsV0FBVyxDQUFDbUIsUUFBUTtRQUVwQmxCLGNBQWMsQ0FBQ1ksV0FBVztRQUMxQlEsWUFBWSxDQUFDQyxPQUFPLENBQUMsQ0FBYSxjQUFFVCxXQUFXO1FBQy9DUSxZQUFZLENBQUNDLE9BQU8sQ0FBQyxDQUFVLFdBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDTCxRQUFRO1FBRXhEakIsTUFBTSxDQUFDdUIsSUFBSSxDQUFDLENBQXlCO0lBRXZDLENBQUM7SUFFRCxNQUFNLDZFQUNIQyxDQUFHOzt3RkFDQ0EsQ0FBRzs7b0JBQUMsQ0FBTTtnR0FBT0MsQ0FBSzt3QkFBQ0MsSUFBSSxFQUFDLENBQU07d0JBQUNDLFFBQVEsRUFBRXpCLGFBQWE7Ozs7Ozs7Ozs7Ozt3RkFDcERzQixDQUFIOztvQkFBQyxDQUFPO2dHQUFTQyxDQUFLO3dCQUFDQyxJQUFJLEVBQUMsQ0FBVTt3QkFBQ0MsUUFBUSxFQUFFckIsZ0JBQWdCOzs7Ozs7Ozs7Ozs7d0ZBQzVEa0IsQ0FBTDtzR0FBRUksQ0FBTTtvQkFBQ0MsT0FBTyxFQUFFdEIsYUFBYTs4QkFBRSxDQUFHOzs7Ozs7Ozs7Ozs7Ozs7OztBQUdoRCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy9xdWl6MDYvcGF5bWVudC9sb2dpbi9pbmRleC50c3g/NmNmZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBncWwsIHVzZUFwb2xsb0NsaWVudCwgdXNlTXV0YXRpb24gfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIlxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCJcbmltcG9ydCB7IHVzZUZvcm1TdGF0ZSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIlxuaW1wb3J0IHsgdXNlUmVjb2lsU3RhdGUgfSBmcm9tIFwicmVjb2lsXCJcbmltcG9ydCB7IGFjY2Vzc1Rva2VuU3RhdGUsIHVzZXJJbmZvbWF0aW9uU3RhdGUgfSBmcm9tIFwiLi4vLi4vLi4vLi4vc3JjL2NvbW1vbnMvc3RvcmVcIlxuXG5jb25zdCBMT0dJTl9VU0VSID0gZ3FsYFxuICBtdXRhdGlvbiBsb2dpblVzZXIoJGVtYWlsOiBTdHJpbmchLCAkcGFzc3dvcmQ6IFN0cmluZyEpIHtcbiAgICBsb2dpblVzZXIoZW1haWw6ICRlbWFpbCwgcGFzc3dvcmQ6ICRwYXNzd29yZCl7XG4gICAgICBhY2Nlc3NUb2tlblxuICAgIH1cbiAgfVxuYCBcblxuXG5cbmNvbnN0IEZFVENIX1VTRVJfTE9HR0VEX0lOID0gZ3FsYFxuICBxdWVyeSBmZXRjaFVzZXJMb2dnZWRJbiB7XG4gICAgZmV0Y2hVc2VyTG9nZ2VkSW4ge1xuICAgICAgX2lkXG4gICAgICBlbWFpbFxuICAgICAgbmFtZVxuICAgICAgdXNlclBvaW50e1xuICAgICAgICBhbW91bnRcbiAgICAgIH1cbiAgICB9XG4gIH1cbmBcblxuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBheW1lbnRMb2dpblBhZ2UgKCkge1xuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIilcbiAgY29uc3QgW2xvZ2luVXNlcl0gPSB1c2VNdXRhdGlvbihMT0dJTl9VU0VSKVxuICBjb25zdCBbLCBzZXRVc2VySW5mb10gPSAgdXNlUmVjb2lsU3RhdGUodXNlckluZm9tYXRpb25TdGF0ZSlcbiAgY29uc3QgWywgc2V0QWNjZXNzVG9rZW5dID0gdXNlUmVjb2lsU3RhdGUoYWNjZXNzVG9rZW5TdGF0ZSlcblxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuXG4gIGNvbnN0IGNsaWVudCA9IHVzZUFwb2xsb0NsaWVudCgpXG4gIFxuICBjb25zdCBvbkNoYW5nZUVtYWlsID0gKGUpID0+IHtcbiAgICBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSlcbiAgfVxuXG4gIGNvbnN0IG9uQ2hhbmdlUGFzc3dvcmQgPSAoZSkgPT4ge1xuICAgIHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKVxuICB9XG5cbiAgY29uc3Qgb25TdWJtaXRMb2dpbiA9IGFzeW5jIChkYXRhKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgbG9naW5Vc2VyKHtcbiAgICAgIHZhcmlhYmxlczoge1xuICAgICAgICBlbWFpbCxcbiAgICAgICAgcGFzc3dvcmRcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSByZXN1bHQuZGF0YS5sb2dpblVzZXIuYWNjZXNzVG9rZW5cbiAgICBzZXRBY2Nlc3NUb2tlbihhY2Nlc3NUb2tlbilcblxuICAgIGNvbnN0IHJlc3VsdFVzZXJJbmZvID0gYXdhaXQgY2xpZW50LnF1ZXJ5KHtcbiAgICAgIHF1ZXJ5OiBGRVRDSF9VU0VSX0xPR0dFRF9JTixcbiAgICAgIGNvbnRleHQ6IHtcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHthY2Nlc3NUb2tlbn1gXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuXG4gICAgY29uc3QgdXNlckluZm8gPSByZXN1bHRVc2VySW5mby5kYXRhLmZldGNoVXNlckxvZ2dlZEluXG5cbiAgICBzZXRVc2VySW5mbyh1c2VySW5mbylcblxuICAgIHNldEFjY2Vzc1Rva2VuKGFjY2Vzc1Rva2VuKTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImFjY2Vzc1Rva2VuXCIsIGFjY2Vzc1Rva2VuKVxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidXNlckluZm9cIiwgSlNPTi5zdHJpbmdpZnkodXNlckluZm8pKVxuXG4gICAgcm91dGVyLnB1c2goJy9xdWl6MDYvcGF5bWVudC9sb2FkaW5nJylcblxuICB9XG4gXG4gIHJldHVybihcbiAgICA8ZGl2PlxuICAgICAgICA8ZGl2PuuhnOq3uOyduCA6IDxpbnB1dCB0eXBlPVwidGV4dFwiIG9uQ2hhbmdlPXtvbkNoYW5nZUVtYWlsfSAvPjwvZGl2PlxuICAgICAgICA8ZGl2Puu5hOuwgOuyiO2YuCA6IDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBvbkNoYW5nZT17b25DaGFuZ2VQYXNzd29yZH0gLz48L2Rpdj5cbiAgICAgICAgPGRpdj48YnV0dG9uIG9uQ2xpY2s9e29uU3VibWl0TG9naW59PuuhnOq3uOyduDwvYnV0dG9uPjwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59Il0sIm5hbWVzIjpbImdxbCIsInVzZUFwb2xsb0NsaWVudCIsInVzZU11dGF0aW9uIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJ1c2VSZWNvaWxTdGF0ZSIsImFjY2Vzc1Rva2VuU3RhdGUiLCJ1c2VySW5mb21hdGlvblN0YXRlIiwiTE9HSU5fVVNFUiIsIkZFVENIX1VTRVJfTE9HR0VEX0lOIiwiUGF5bWVudExvZ2luUGFnZSIsImVtYWlsIiwic2V0RW1haWwiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwibG9naW5Vc2VyIiwic2V0VXNlckluZm8iLCJzZXRBY2Nlc3NUb2tlbiIsInJvdXRlciIsImNsaWVudCIsIm9uQ2hhbmdlRW1haWwiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJvbkNoYW5nZVBhc3N3b3JkIiwib25TdWJtaXRMb2dpbiIsImRhdGEiLCJyZXN1bHQiLCJ2YXJpYWJsZXMiLCJhY2Nlc3NUb2tlbiIsInJlc3VsdFVzZXJJbmZvIiwicXVlcnkiLCJjb250ZXh0IiwiaGVhZGVycyIsIkF1dGhvcml6YXRpb24iLCJ1c2VySW5mbyIsImZldGNoVXNlckxvZ2dlZEluIiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsIkpTT04iLCJzdHJpbmdpZnkiLCJwdXNoIiwiZGl2IiwiaW5wdXQiLCJ0eXBlIiwib25DaGFuZ2UiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/quiz06/payment/login/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState),\n/* harmony export */   \"userInfomationState\": () => (/* binding */ userInfomationState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"isEditState\",\n    default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"accessTokenState\",\n    default: \"\"\n});\nconst userInfomationState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"userInfoState\",\n    default: {\n        email: \"\",\n        name: \"\"\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUE2QjtBQUV0QixLQUFLLENBQUNDLFdBQVcsR0FBR0QsNENBQUksQ0FBQyxDQUFDO0lBQy9CRSxHQUFHLEVBQUUsQ0FBYTtJQUNsQkMsT0FBTyxFQUFFLEtBQUs7QUFDaEIsQ0FBQztBQUVNLEtBQUssQ0FBQ0MsZ0JBQWdCLEdBQUdKLDRDQUFJLENBQUMsQ0FBQztJQUNwQ0UsR0FBRyxFQUFFLENBQWtCO0lBQ3ZCQyxPQUFPLEVBQUUsQ0FBRTtBQUNiLENBQUM7QUFFTSxLQUFLLENBQUNFLG1CQUFtQixHQUFHTCw0Q0FBSSxDQUFDLENBQUM7SUFDdkNFLEdBQUcsRUFBRSxDQUFlO0lBQ3BCQyxPQUFPLEVBQUUsQ0FBQztRQUNSRyxLQUFLLEVBQUUsQ0FBRTtRQUNUQyxJQUFJLEVBQUUsQ0FBRTtJQUNWLENBQUM7QUFDSCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cz8zY2JmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGF0b20gfSBmcm9tIFwicmVjb2lsXCI7XG5cbmV4cG9ydCBjb25zdCBpc0VkaXRTdGF0ZSA9IGF0b20oe1xuICBrZXk6IFwiaXNFZGl0U3RhdGVcIixcbiAgZGVmYXVsdDogZmFsc2Vcbn0pXG5cbmV4cG9ydCBjb25zdCBhY2Nlc3NUb2tlblN0YXRlID0gYXRvbSh7XG4gIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXG4gIGRlZmF1bHQ6IFwiXCJcbn0pXG5cbmV4cG9ydCBjb25zdCB1c2VySW5mb21hdGlvblN0YXRlID0gYXRvbSh7XG4gIGtleTogXCJ1c2VySW5mb1N0YXRlXCIsXG4gIGRlZmF1bHQ6IHtcbiAgICBlbWFpbDogXCJcIixcbiAgICBuYW1lOiBcIlwiXG4gIH1cbn0pIl0sIm5hbWVzIjpbImF0b20iLCJpc0VkaXRTdGF0ZSIsImtleSIsImRlZmF1bHQiLCJhY2Nlc3NUb2tlblN0YXRlIiwidXNlckluZm9tYXRpb25TdGF0ZSIsImVtYWlsIiwibmFtZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/quiz06/payment/login/index.tsx"));
module.exports = __webpack_exports__;

})();