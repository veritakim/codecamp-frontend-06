"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/quiz06/payment/complete";
exports.ids = ["pages/quiz06/payment/complete"];
exports.modules = {

/***/ "./pages/quiz06/payment/complete/index.tsx":
/*!*************************************************!*\
  !*** ./pages/quiz06/payment/complete/index.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ PaymentCompletePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst FETCH_USER_LOGGED_IN = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  query fetchUserLoggedIn {\n    fetchUserLoggedIn {\n      _id\n      email\n      name\n      userPoint {\n        amount\n      }\n    }\n  }\n`;\nconst FETCH_POINT_TRANSACTIONS = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n query fetchPointTransactions{\n  fetchPointTransactions{\n    _id\n    amount\n    user {\n      _id\n      name\n    }\n  }\n }\n`;\nfunction PaymentCompletePage() {\n    const { data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useQuery)(FETCH_USER_LOGGED_IN);\n    // const {data} = useQuery(FETCH_POINT_TRANSACTIONS)\n    console.log(data);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: \"결제성공\"\n    }, void 0, false, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/quiz06/payment/complete/index.tsx\",\n        lineNumber: 41,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9xdWl6MDYvcGF5bWVudC9jb21wbGV0ZS9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQThDO0FBSTlDLEtBQUssQ0FBQ0Usb0JBQW9CLEdBQUdGLCtDQUFHLENBQUM7Ozs7Ozs7Ozs7O0FBV2pDO0FBRUEsS0FBSyxDQUFDRyx3QkFBd0IsR0FBR0gsK0NBQUcsQ0FBQzs7Ozs7Ozs7Ozs7QUFXckM7QUFHZSxRQUFRLENBQUNJLG1CQUFtQixHQUFJLENBQUM7SUFDOUMsS0FBSyxDQUFDLENBQUNDLENBQUFBLElBQUksR0FBQyxHQUFHSix3REFBUSxDQUFDQyxvQkFBb0I7SUFDNUMsRUFBb0Q7SUFJcERJLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRixJQUFJO0lBQ2hCLE1BQU0sNkVBRUhHLENBQUc7a0JBQUMsQ0FBSTs7Ozs7O0FBRWIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvcXVpejA2L3BheW1lbnQvY29tcGxldGUvaW5kZXgudHN4PzE5ZDciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ3FsLCB1c2VRdWVyeSB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiXG5pbXBvcnQgeyB1c2VSZWNvaWxTdGF0ZSB9IGZyb20gXCJyZWNvaWxcIlxuaW1wb3J0IHsgdXNlckluZm9tYXRpb25TdGF0ZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9zcmMvY29tbW9ucy9zdG9yZVwiXG5cbmNvbnN0IEZFVENIX1VTRVJfTE9HR0VEX0lOID0gZ3FsYFxuICBxdWVyeSBmZXRjaFVzZXJMb2dnZWRJbiB7XG4gICAgZmV0Y2hVc2VyTG9nZ2VkSW4ge1xuICAgICAgX2lkXG4gICAgICBlbWFpbFxuICAgICAgbmFtZVxuICAgICAgdXNlclBvaW50IHtcbiAgICAgICAgYW1vdW50XG4gICAgICB9XG4gICAgfVxuICB9XG5gXG5cbmNvbnN0IEZFVENIX1BPSU5UX1RSQU5TQUNUSU9OUyA9IGdxbGBcbiBxdWVyeSBmZXRjaFBvaW50VHJhbnNhY3Rpb25ze1xuICBmZXRjaFBvaW50VHJhbnNhY3Rpb25ze1xuICAgIF9pZFxuICAgIGFtb3VudFxuICAgIHVzZXIge1xuICAgICAgX2lkXG4gICAgICBuYW1lXG4gICAgfVxuICB9XG4gfVxuYFxuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBheW1lbnRDb21wbGV0ZVBhZ2UgKCkge1xuICBjb25zdCB7ZGF0YX0gPSB1c2VRdWVyeShGRVRDSF9VU0VSX0xPR0dFRF9JTilcbiAgLy8gY29uc3Qge2RhdGF9ID0gdXNlUXVlcnkoRkVUQ0hfUE9JTlRfVFJBTlNBQ1RJT05TKVxuXG5cblxuICBjb25zb2xlLmxvZyhkYXRhKVxuICByZXR1cm4gKFxuICAgIFxuICAgIDxkaXY+6rKw7KCc7ISx6rO1PC9kaXY+XG4gIClcbn0iXSwibmFtZXMiOlsiZ3FsIiwidXNlUXVlcnkiLCJGRVRDSF9VU0VSX0xPR0dFRF9JTiIsIkZFVENIX1BPSU5UX1RSQU5TQUNUSU9OUyIsIlBheW1lbnRDb21wbGV0ZVBhZ2UiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsImRpdiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/quiz06/payment/complete/index.tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/quiz06/payment/complete/index.tsx"));
module.exports = __webpack_exports__;

})();