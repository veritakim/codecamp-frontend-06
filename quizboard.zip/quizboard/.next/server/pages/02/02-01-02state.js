"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/02/02-01-02state";
exports.ids = ["pages/02/02-01-02state"];
exports.modules = {

/***/ "./pages/02/02-01-02state/index.js":
/*!*****************************************!*\
  !*** ./pages/02/02-01-02state/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ StateQuiz)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction StateQuiz() {\n    const { 0: hello , 1: setHello  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"안녕하세요\");\n    function onClickHello() {\n        setHello(\"반갑습니다\");\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n        onClick: onClickHello,\n        children: hello\n    }, void 0, false, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-01-02state/index.js\",\n        lineNumber: 12,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wMi8wMi0wMS0wMnN0YXRlL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE4QjtBQUVmLFFBQVEsQ0FBQ0MsU0FBUyxHQUFJLENBQUM7SUFFcEMsS0FBSyxNQUFFQyxLQUFLLE1BQUVDLFFBQVEsTUFBSUgsK0NBQVEsQ0FBQyxDQUFPO2FBRXZCSSxZQUFFLEdBQUksQ0FBQztRQUN4QkQsUUFBUSxDQUFDLENBQU87SUFDbEIsQ0FBQztJQUVELE1BQU0sNkVBQ0hFLENBQU07UUFBQ0MsT0FBTyxFQUFFRixZQUFZO2tCQUFHRixLQUFLOzs7Ozs7QUFFekMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDIvMDItMDEtMDJzdGF0ZS9pbmRleC5qcz82NTI2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7dXNlU3RhdGV9IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU3RhdGVRdWl6ICgpIHtcblxuICBjb25zdCBbaGVsbG8sIHNldEhlbGxvXSA9IHVzZVN0YXRlKFwi7JWI64WV7ZWY7IS47JqUXCIpO1xuXG4gIGZ1bmN0aW9uIG9uQ2xpY2tIZWxsbyAoKSB7XG4gICAgc2V0SGVsbG8oXCLrsJjqsJHsirXri4jri6RcIik7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxidXR0b24gb25DbGljaz17b25DbGlja0hlbGxvfT57aGVsbG99PC9idXR0b24+XG4gIClcbn0iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJTdGF0ZVF1aXoiLCJoZWxsbyIsInNldEhlbGxvIiwib25DbGlja0hlbGxvIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/02/02-01-02state/index.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/02/02-01-02state/index.js"));
module.exports = __webpack_exports__;

})();