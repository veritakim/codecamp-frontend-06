"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/02/02-02-01class";
exports.ids = ["pages/02/02-02-01class"];
exports.modules = {

/***/ "./pages/02/02-02-01class/index.js":
/*!*****************************************!*\
  !*** ./pages/02/02-02-01class/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ClassCountPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction ClassCountPage() {\n    function countPlus() {\n        let num = Number(document.getElementById(\"countNumber\").innerText);\n        document.getElementById(\"countNumber\").innerText = num + 1;\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                id: \"countNumber\",\n                children: \"0\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-02-01class/index.js\",\n                lineNumber: 13,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: countPlus,\n                children: \"카운트 증가\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-02-01class/index.js\",\n                lineNumber: 14,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-02-01class/index.js\",\n        lineNumber: 12,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wMi8wMi0wMi0wMWNsYXNzL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBZSxRQUFRLENBQUNBLGNBQWMsR0FBSSxDQUFDO2FBRWhDQyxTQUFTLEdBQUksQ0FBQztRQUNyQixHQUFHLENBQUNDLEdBQUcsR0FBR0MsTUFBTSxDQUFDQyxRQUFRLENBQUNDLGNBQWMsQ0FBQyxDQUFhLGNBQUVDLFNBQVM7UUFFakVGLFFBQVEsQ0FBQ0MsY0FBYyxDQUFDLENBQWEsY0FBRUMsU0FBUyxHQUFHSixHQUFHLEdBQUcsQ0FBQztJQUU1RCxDQUFDO0lBR0QsTUFBTSw2RUFDSEssQ0FBRzs7d0ZBQ0RBLENBQUc7Z0JBQUNDLEVBQUUsRUFBQyxDQUFhOzBCQUFDLENBQUM7Ozs7Ozt3RkFDdEJDLENBQU07Z0JBQUNDLE9BQU8sRUFBRVQsU0FBUzswQkFBRSxDQUFNOzs7Ozs7Ozs7Ozs7QUFHeEMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDIvMDItMDItMDFjbGFzcy9pbmRleC5qcz8xYzg2Il0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENsYXNzQ291bnRQYWdlICgpIHtcblxuICBmdW5jdGlvbiBjb3VudFBsdXMgKCkge1xuICAgIGxldCBudW0gPSBOdW1iZXIoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjb3VudE51bWJlclwiKS5pbm5lclRleHQpXG5cbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNvdW50TnVtYmVyXCIpLmlubmVyVGV4dCA9IG51bSArIDFcblxuICB9XG5cbiAgXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXYgaWQ9XCJjb3VudE51bWJlclwiPjA8L2Rpdj5cbiAgICAgIDxidXR0b24gb25DbGljaz17Y291bnRQbHVzfT7subTsmrTtirgg7Kad6rCAPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIClcbn0iXSwibmFtZXMiOlsiQ2xhc3NDb3VudFBhZ2UiLCJjb3VudFBsdXMiLCJudW0iLCJOdW1iZXIiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiaW5uZXJUZXh0IiwiZGl2IiwiaWQiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/02/02-02-01class/index.js\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/02/02-02-01class/index.js"));
module.exports = __webpack_exports__;

})();