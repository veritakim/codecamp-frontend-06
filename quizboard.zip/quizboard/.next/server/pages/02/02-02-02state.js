"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/02/02-02-02state";
exports.ids = ["pages/02/02-02-02state"];
exports.modules = {

/***/ "./pages/02/02-02-02state/index.js":
/*!*****************************************!*\
  !*** ./pages/02/02-02-02state/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ CountUpState)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction CountUpState() {\n    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);\n    function countUp() {\n        setCount(count + 1);\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: count\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-02-02state/index.js\",\n                lineNumber: 12,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: countUp,\n                children: \"증가해라\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-02-02state/index.js\",\n                lineNumber: 13,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-02-02state/index.js\",\n        lineNumber: 11,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wMi8wMi0wMi0wMnN0YXRlL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE4QjtBQUVmLFFBQVEsQ0FBQ0MsWUFBWSxHQUFJLENBQUM7SUFDdkMsS0FBSyxNQUFFQyxLQUFLLE1BQUVDLFFBQVEsTUFBSUgsK0NBQVEsQ0FBQyxDQUFDO2FBRTNCSSxPQUFPLEdBQUksQ0FBQztRQUNuQkQsUUFBUSxDQUFDRCxLQUFLLEdBQUcsQ0FBQztJQUNwQixDQUFDO0lBRUQsTUFBTSw2RUFDSEcsQ0FBRzs7d0ZBQ0RBLENBQUc7MEJBQUVILEtBQUs7Ozs7Ozt3RkFDVkksQ0FBTTtnQkFBQ0MsT0FBTyxFQUFFSCxPQUFPOzBCQUFFLENBQUk7Ozs7Ozs7Ozs7OztBQUlwQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy8wMi8wMi0wMi0wMnN0YXRlL2luZGV4LmpzP2JmYWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHt1c2VTdGF0ZX0gZnJvbSAncmVhY3QnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvdW50VXBTdGF0ZSAoKSB7XG4gIGNvbnN0IFtjb3VudCwgc2V0Q291bnRdID0gdXNlU3RhdGUoMCk7XG5cbiAgZnVuY3Rpb24gY291bnRVcCAoKSB7XG4gICAgc2V0Q291bnQoY291bnQgKyAxKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXY+e2NvdW50fTwvZGl2PlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtjb3VudFVwfT7spp3qsIDtlbTrnbw8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKVxuXG59Il0sIm5hbWVzIjpbInVzZVN0YXRlIiwiQ291bnRVcFN0YXRlIiwiY291bnQiLCJzZXRDb3VudCIsImNvdW50VXAiLCJkaXYiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/02/02-02-02state/index.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/02/02-02-02state/index.js"));
module.exports = __webpack_exports__;

})();