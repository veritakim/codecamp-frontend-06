"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/02/02-03-02state";
exports.ids = ["pages/02/02-03-02state"];
exports.modules = {

/***/ "./pages/02/02-03-02state/index.js":
/*!*****************************************!*\
  !*** ./pages/02/02-03-02state/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ AuthNumberStatePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction AuthNumberStatePage() {\n    const { 0: authNum , 1: setRandom  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"000000\");\n    function authRandom() {\n        setRandom(String(Math.floor(Math.random() * 1000000)).padStart(6, \"0\"));\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: authNum\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-03-02state/index.js\",\n                lineNumber: 12,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: authRandom,\n                children: \"인증번호 발송\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-03-02state/index.js\",\n                lineNumber: 13,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-03-02state/index.js\",\n        lineNumber: 11,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wMi8wMi0wMy0wMnN0YXRlL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFnQztBQUVqQixRQUFRLENBQUNDLG1CQUFtQixHQUFJLENBQUM7SUFDOUMsS0FBSyxNQUFFQyxPQUFPLE1BQUVDLFNBQVMsTUFBSUgsK0NBQVEsQ0FBQyxDQUFRO2FBRXJDSSxVQUFVLEdBQUksQ0FBQztRQUN0QkQsU0FBUyxDQUFDRSxNQUFNLENBQUNDLElBQUksQ0FBQ0MsS0FBSyxDQUFDRCxJQUFJLENBQUNFLE1BQU0sS0FBSyxPQUFPLEdBQUdDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBRztJQUN2RSxDQUFDO0lBRUQsTUFBTSw2RUFDSEMsQ0FBRzs7d0ZBQ0RBLENBQUc7MEJBQUVSLE9BQU87Ozs7Ozt3RkFDWlMsQ0FBTTtnQkFBQ0MsT0FBTyxFQUFFUixVQUFVOzBCQUFFLENBQU87Ozs7Ozs7Ozs7OztBQUcxQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy8wMi8wMi0wMy0wMnN0YXRlL2luZGV4LmpzP2NiOTIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBdXRoTnVtYmVyU3RhdGVQYWdlICgpIHtcbiAgY29uc3QgW2F1dGhOdW0sIHNldFJhbmRvbV0gPSB1c2VTdGF0ZShcIjAwMDAwMFwiKTtcblxuICBmdW5jdGlvbiBhdXRoUmFuZG9tICgpIHtcbiAgICBzZXRSYW5kb20oU3RyaW5nKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDAwMDApKS5wYWRTdGFydCg2LCBcIjBcIikpO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdj57YXV0aE51bX08L2Rpdj5cbiAgICAgIDxidXR0b24gb25DbGljaz17YXV0aFJhbmRvbX0+7J247Kad67KI7Zi4IOuwnOyGoTwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApXG59Il0sIm5hbWVzIjpbInVzZVN0YXRlIiwiQXV0aE51bWJlclN0YXRlUGFnZSIsImF1dGhOdW0iLCJzZXRSYW5kb20iLCJhdXRoUmFuZG9tIiwiU3RyaW5nIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwicGFkU3RhcnQiLCJkaXYiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/02/02-03-02state/index.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/02/02-03-02state/index.js"));
module.exports = __webpack_exports__;

})();