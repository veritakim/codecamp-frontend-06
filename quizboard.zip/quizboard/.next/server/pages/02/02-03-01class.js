"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/02/02-03-01class";
exports.ids = ["pages/02/02-03-01class"];
exports.modules = {

/***/ "./pages/02/02-03-01class/index.js":
/*!*****************************************!*\
  !*** ./pages/02/02-03-01class/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ AuthNumber)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction AuthNumber() {\n    function makeRandom() {\n        let random = String(Math.floor(Math.random() * 1000000)).padStart(6, \"0\");\n        // document.getElementById(\"btn\").disabled = true;\n        document.getElementById(\"randomNum\").innerText = random;\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                id: \"randomNum\",\n                children: \"000000\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-03-01class/index.js\",\n                lineNumber: 14,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                id: \"btn\",\n                onClick: makeRandom,\n                children: \"인증번호 전송\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-03-01class/index.js\",\n                lineNumber: 15,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/02/02-03-01class/index.js\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wMi8wMi0wMy0wMWNsYXNzL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBZSxRQUFRLENBQUNBLFVBQVUsR0FBSyxDQUFDO2FBRTdCQyxVQUFVLEdBQUksQ0FBQztRQUV0QixHQUFHLENBQUNDLE1BQU0sR0FBR0MsTUFBTSxDQUFDQyxJQUFJLENBQUNDLEtBQUssQ0FBQ0QsSUFBSSxDQUFDRixNQUFNLEtBQUssT0FBTyxHQUFHSSxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUc7UUFFeEUsRUFBa0Q7UUFFbERDLFFBQVEsQ0FBQ0MsY0FBYyxDQUFDLENBQVcsWUFBRUMsU0FBUyxHQUFHUCxNQUFNO0lBQ3pELENBQUM7SUFFRCxNQUFNLDZFQUNIUSxDQUFHOzt3RkFDREEsQ0FBRztnQkFBQ0MsRUFBRSxFQUFDLENBQVc7MEJBQUMsQ0FBTTs7Ozs7O3dGQUN6QkMsQ0FBTTtnQkFBQ0QsRUFBRSxFQUFDLENBQUs7Z0JBQUNFLE9BQU8sRUFBRVosVUFBVTswQkFBRSxDQUFPOzs7Ozs7Ozs7Ozs7QUFJbkQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDIvMDItMDMtMDFjbGFzcy9pbmRleC5qcz9kOGNiIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEF1dGhOdW1iZXIgKCApIHtcblxuICBmdW5jdGlvbiBtYWtlUmFuZG9tICgpIHtcbiAgICBcbiAgICBsZXQgcmFuZG9tID0gU3RyaW5nKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDAwMDApKS5wYWRTdGFydCg2LCBcIjBcIik7XG4gICAgXG4gICAgLy8gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJidG5cIikuZGlzYWJsZWQgPSB0cnVlO1xuXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyYW5kb21OdW1cIikuaW5uZXJUZXh0ID0gcmFuZG9tO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBpZD1cInJhbmRvbU51bVwiPjAwMDAwMDwvZGl2PlxuICAgICAgPGJ1dHRvbiBpZD1cImJ0blwiIG9uQ2xpY2s9e21ha2VSYW5kb219PuyduOymneuyiO2YuCDsoITshqE8L2J1dHRvbj5cbiAgICA8L2Rpdj5cblxuICApXG59Il0sIm5hbWVzIjpbIkF1dGhOdW1iZXIiLCJtYWtlUmFuZG9tIiwicmFuZG9tIiwiU3RyaW5nIiwiTWF0aCIsImZsb29yIiwicGFkU3RhcnQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiaW5uZXJUZXh0IiwiZGl2IiwiaWQiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/02/02-03-01class/index.js\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/02/02-03-01class/index.js"));
module.exports = __webpack_exports__;

})();