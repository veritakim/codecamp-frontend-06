"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/week4-03";
exports.ids = ["pages/week4-03"];
exports.modules = {

/***/ "./pages/week4-03/index.tsx":
/*!**********************************!*\
  !*** ./pages/week4-03/index.tsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ QuizCount)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction QuizCount() {\n    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);\n    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        var ref;\n        console.log(\"컴포넌트가 마운트됐습니다~\");\n        (ref = inputRef.current) === null || ref === void 0 ? void 0 : ref.focus();\n        return ()=>{\n            alert(\"컴포넌트가 제거됩니다~\");\n        };\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        console.log(\"컴포넌트가 변경됐습니다~\");\n    }, [\n        count\n    ]);\n    const onclickCount = ()=>{\n        setCount((prev)=>prev + 1\n        );\n    };\n    const onClickMove = ()=>{\n        router.push('/');\n    };\n    console.log(\"마운트 시작\");\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                ref: inputRef\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/week4-03/index.tsx\",\n                lineNumber: 33,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"카운트 : \",\n                    count\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/week4-03/index.tsx\",\n                lineNumber: 34,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onclickCount,\n                children: \"카운트(+1)\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/week4-03/index.tsx\",\n                lineNumber: 35,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickMove,\n                children: \"이동하기\"\n            }, void 0, false, {\n                fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/week4-03/index.tsx\",\n                lineNumber: 36,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/jinsilkim/Desktop/codecamp-frontend-06/quizboard/pages/week4-03/index.tsx\",\n        lineNumber: 32,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy93ZWVrNC0wMy9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBdUM7QUFDWTtBQUdwQyxRQUFRLENBQUNJLFNBQVMsR0FBSSxDQUFDO0lBQ3BDLEtBQUssTUFBRUMsS0FBSyxNQUFFQyxRQUFRLE1BQUlILCtDQUFRLENBQUMsQ0FBQztJQUNwQyxLQUFLLENBQUNJLFFBQVEsR0FBR0wsNkNBQU0sQ0FBbUIsSUFBSTtJQUM5QyxLQUFLLENBQUNNLE1BQU0sR0FBR1Isc0RBQVM7SUFFeEJDLGdEQUFTLEtBQU8sQ0FBQztZQUVmTSxHQUFnQjtRQURoQkUsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBd0M7U0FDcERILEdBQWdCLEdBQWhCQSxRQUFRLENBQUNJLE9BQU8sY0FBaEJKLEdBQWdCLEtBQWhCQSxJQUFJLENBQUpBLENBQXVCLEdBQXZCQSxJQUFJLENBQUpBLENBQXVCLEdBQXZCQSxHQUFnQixDQUFFSyxLQUFLO1FBRXZCLE1BQU0sS0FBTyxDQUFDO1lBQ1pDLEtBQUssQ0FBQyxDQUFjO1FBQ0YsQ0FBbkI7SUFDSCxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBRUpaLGdEQUFTLEtBQU8sQ0FBQztRQUNmUSxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFlO0lBQ1AsQ0FBckIsRUFBRSxDQUFDTDtRQUFBQSxLQUFLO0lBQUEsQ0FBQztJQUVWLEtBQUssQ0FBQ1MsWUFBWSxPQUFTLENBQUM7UUFDMUJSLFFBQVEsRUFBRVMsSUFBSSxHQUFNQSxJQUFJLEdBQUcsQ0FBQzs7SUFDOUIsQ0FBQztJQUVELEtBQUssQ0FBQ0MsV0FBVyxPQUFTLENBQUM7UUFDekJSLE1BQU0sQ0FBQ1MsSUFBSSxDQUFDLENBQUc7SUFDakIsQ0FBQztJQUNEUixPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFRO0lBQ1YsTUFBSiw2RUFDSFEsQ0FBRzs7d0ZBQ0RDLENBQUs7Z0JBQUNDLElBQUksRUFBQyxDQUFVO2dCQUFDQyxHQUFHLEVBQUVkLFFBQVE7Ozs7Ozt3RkFDbkNXLENBQUc7O29CQUFDLENBQU07b0JBQU9iLEtBQUs7Ozs7Ozs7d0ZBQ2hCaUIsQ0FBQTtnQkFBQ0MsT0FBTyxFQUFFVCxZQUFZOzBCQUFFLENBQU87Ozs7Ozt3RkFDL0JRLENBQUE7Z0JBQUNDLE9BQU8sRUFBRVAsV0FBVzswQkFBRyxDQUFJOzs7Ozs7Ozs7Ozs7QUFLekMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvd2VlazQtMDMvaW5kZXgudHN4PzU0YTIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIlxuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFF1aXpDb3VudCAoKSB7XG4gIGNvbnN0IFtjb3VudCwgc2V0Q291bnRdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc29sZS5sb2coXCLsu7Ttj6zrhIztirjqsIAg66eI7Jq07Yq465CQ7Iq164uI64ukflwiKVxuICAgIGlucHV0UmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYWxlcnQoXCLsu7Ttj6zrhIztirjqsIAg7KCc6rGw65Cp64uI64ukflwiKVxuICAgIH1cbiAgfSxbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwi7Lu07Y+s64SM7Yq46rCAIOuzgOqyveuQkOyKteuLiOuLpH5cIik7XG4gIH0sIFtjb3VudF0pXG5cbiAgY29uc3Qgb25jbGlja0NvdW50ID0gKCkgPT4ge1xuICAgIHNldENvdW50KChwcmV2KSA9PiAocHJldiArIDEpKTsgICAgXG4gIH1cbiAgXG4gIGNvbnN0IG9uQ2xpY2tNb3ZlID0gKCkgPT4ge1xuICAgIHJvdXRlci5wdXNoKCcvJylcbiAgfVxuICBjb25zb2xlLmxvZyhcIuuniOyatO2KuCDsi5zsnpFcIilcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIHJlZj17aW5wdXRSZWZ9IC8+XG4gICAgICA8ZGl2Puy5tOyatO2KuCA6IHtjb3VudH08L2Rpdj5cbiAgICAgIDxidXR0b24gb25DbGljaz17b25jbGlja0NvdW50fT7subTsmrTtirgoKzEpPC9idXR0b24+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tNb3ZlfSA+7J2064+Z7ZWY6riwPC9idXR0b24+XG4gICAgPC9kaXY+XG5cbiAgKVxuXG59Il0sIm5hbWVzIjpbInVzZVJvdXRlciIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiUXVpekNvdW50IiwiY291bnQiLCJzZXRDb3VudCIsImlucHV0UmVmIiwicm91dGVyIiwiY29uc29sZSIsImxvZyIsImN1cnJlbnQiLCJmb2N1cyIsImFsZXJ0Iiwib25jbGlja0NvdW50IiwicHJldiIsIm9uQ2xpY2tNb3ZlIiwicHVzaCIsImRpdiIsImlucHV0IiwidHlwZSIsInJlZiIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/week4-03/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/week4-03/index.tsx"));
module.exports = __webpack_exports__;

})();