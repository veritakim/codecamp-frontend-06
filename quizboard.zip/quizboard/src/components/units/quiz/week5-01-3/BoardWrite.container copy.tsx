import RecoilPresenterPage from "./BoardWrite.presenter";

export default function RecoilContainerPage () {

  return <RecoilPresenterPage />
}