import styled from "@emotion/styled"

const Wrapper = styled.div`
  height: 50px;
  background-color: #a5402f;
`

export default function LayoutHeader () {


  return <Wrapper>헤더영역</Wrapper>;
}